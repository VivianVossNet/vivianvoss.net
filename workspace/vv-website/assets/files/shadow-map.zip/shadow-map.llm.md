# Shadow Map — Referenzimplementierung & Integrationsleitfaden

Dieses Dokument begleitet `shadow-map.html`, eine funktionierende Referenzimplementierung für Echtzeit-Gebäudeschattenprojektion auf einer interaktiven Karte. Es ist dafür gedacht, von einem KI-Coding-Assistenten (Claude Code, Cursor, etc.) gelesen zu werden, um den erprobten Ansatz zu verstehen und in eine bestehende oder neue Codebasis zu integrieren.

---

## Was das löst

Gegeben: Kartenposition, Datum und Uhrzeit — berechne, welche Gebäude wohin Schatten werfen, und bestimme für jedes Restaurant/Café, ob es gerade in der Sonne oder im Schatten liegt. Die Berechnung ist weltweit korrekt: Sonnenposition, Schattenrichtung und Tag/Nacht-Status werden aus UTC und geographischer Länge abgeleitet.

---

## Erprobte Architektur (shadow-map.html)

Die Referenzdatei implementiert die komplette Pipeline in ~375 Zeilen clientseitigem JavaScript mit **Mapbox GL JS v3.3** und dem **light-v11** Style. Die Kernlogik ist kartenanbieter-agnostisch. Jede Stufe ist unten extrahiert, damit sie auf jeden Stack portiert werden kann.

### 1. Sonnenposition aus UTC + Koordinaten

```
Eingabe:  Date, UTC-Stunde (dezimal), Breitengrad, Längengrad
Ausgabe:  { altitude (rad), azimuth (rad), up (bool) }
```

Die Berechnung verwendet:
- Tag-des-Jahres zur Berechnung der Sonnendeklination über `23.45° * sin(B)` wobei `B = (360/365) * (doy - 81)`
- Zeitgleichungs-Korrektur (Equation of Time): `9.87 * sin(2B) - 7.53 * cos(B) - 1.5 * sin(B)`
- **Direkte Solarzeit aus UTC + Längengrad:** `st = utcHour + lon / 15 + eot / 60` (keine STM-Approximation)
- Stundenwinkel, dann Höhe und Azimut aus sphärischer Trigonometrie

Genauigkeit ~1 Grad — ausreichend für Schattenvisualisierung. NICHT durch eine schwerere Bibliothek ersetzen, es sei denn Sub-Bogenminuten-Präzision ist erforderlich.

**KRITISCH:** Die Funktion erwartet UTC als Eingabe, NICHT lokale Zeit. Die Konvertierung Lokalzeit → UTC erfolgt im UI-Layer über den Zeitzonen-Offset `round(lon / 15)`.

### 2. Zeitzonen und Slider-Logik

Der Time-Slider steuert die **Lokalzeit am betrachteten Kartenort**. Intern wird zu UTC konvertiert:

```
tzOff = round(longitude / 15)          // Zeitzone aus Längengrad
utcHour = (localHour - tzOff + 24) % 24  // Lokale → UTC
localHour = (utcHour + tzOff + 24) % 24  // UTC → Lokale
```

**Automatische Slider-Verschiebung beim Zonenwechsel:** Wenn der Benutzer zu einer anderen Zeitzone pannt, verschiebt sich der Slider automatisch, um den gleichen UTC-Moment beizubehalten. Berlin 14:00 wird zu New York 08:00. Die Logik:

```
if (tzOff !== lastTzOff) {
  localHour = (localHour + (tzOff - lastTzOff) + 24) % 24;
  slider.value = localHour;
  lastTzOff = tzOff;
}
```

Der **"Now"-Button** springt zur aktuellen Echtzeit am betrachteten Ort.

Die Anzeige zeigt: Lokalzeit (groß), Zeitzone (`UTC+1`), und Greenwich-Zeit (`GMT 11:30`).

### 3. Schattenprojektion pro Gebäude

```
Eingabe:  Gebäudegrundriss-Ring (Polygon-Koordinaten), Höhe (m), Sonnenposition, Breitengrad
Ausgabe:  Schattenpolygon (geschlossener Ring)
```

Schritte:
1. Schatten-Offset in Grad berechnen: `Länge = Höhe / tan(altitude)`, gedeckelt bei `Höhe * 4` für niedrige Sonnenstände
2. Meter in Grad-Offset umrechnen: `dx = -len * sin(az) / (111320 * cos(lat))`, `dy = -len * cos(az) / 111320`
3. Für jeden Grundriss-Vertex den schattenprojizierten Zwilling erzeugen: `[lon + dx, lat + dy]`
4. **Konvexe Hülle** aller Original- + projizierten Vertices berechnen (Monotone Chain, O(n log n))
5. Ring schließen

**KRITISCH: Schattenrichtung.** Der Schatten fällt ENTGEGENGESETZT zur Sonnenrichtung. Beide Offset-Komponenten (dx UND dy) müssen negiert werden (`-len * sin(az)`, `-len * cos(az)`). Ein häufiger Bug ist, nur dy zu negieren, was die Ost-West-Richtung spiegelt.

**KRITISCH: Schattenlängen-Cap.** Der Cap `Höhe * 4` begrenzt Schatten auf das 4-fache der Gebäudehöhe. Dies entspricht einem Sonnenstand von ca. 14°. Bei niedrigeren Sonnenständen sind Schatten in der Praxis nicht mehr relevant, da die Nachtphase einsetzt.

**Kritischer Bugfix bereits enthalten:** Ein Restaurant, das physisch in Gebäude A liegt, darf NICHT als beschattet durch Gebäude A's eigenes Schattenpolygon markiert werden (das natürlich den Grundriss umschließt). Der Test lautet:

```
shadowed = !sun.up || shadows.some(s => pointInPolygon(punkt, s.shadow) && !pointInPolygon(punkt, s.footprint))
```

Bedeutet: nur Schatten von ANDEREN Gebäuden zählen. Nachts sind alle Restaurants automatisch `shadowed: true`.

### 4. Punkt-in-Polygon (Ray Casting)

Standard Even-Odd Ray-Casting-Algorithmus. Keine Abhängigkeiten. Funktioniert für jedes einfache Polygon.

### 5. Gebäudedatenquelle

Die Referenz verwendet **Mapbox Vector Tiles** (`composite`-Quelle, `building`-Source-Layer). Gebäude mit `height > 0` werden über `queryRenderedFeatures` mit einem **200px-Puffer** über den sichtbaren Viewport hinaus abgefragt. Dieser Puffer verhindert abgehackte Schattenkanten am Bildschirmrand. Das liefert echte 3D-Gebäudedaten weltweit ohne externe API-Aufrufe.

### 6. Restaurantdatenquelle

Restaurants und Cafés werden aus **Mapbox-POI-Daten** abgefragt (`poi_label`-Source-Layer, gefiltert nach `maki === 'restaurant' || maki === 'cafe'`). Ein versteckter Loader-Layer stellt sicher, dass Tile-Daten geladen werden, auch wenn kein sichtbarer POI-Layer im Style existiert.

### 7. Restaurant-Schattenstatus

Jedes Restaurant-Feature erhält eine `shadowed: true|false`-Property. **Nachts** (Sonne unter Horizont) sind alle Restaurants automatisch `shadowed: true`. Die Darstellung:
- **Hellgrüner Punkt** (`#6ecf5e`) = in der Sonne
- **Dunkelgrüner Punkt** (`#2a7a22`) = im Schatten

Ein Klick-Popup zeigt: Name (Versalien), Typ und Sonnen-/Schatten-Statusbadge.

### 8. Tag-Nacht-Übergang

Die Referenz implementiert einen fließenden Crossfade zwischen Gebäudeschatten und Nacht-Overlay:

- **Gebäudeschatten-Opazität:** skaliert linear mit Sonnenhöhe. 0° = 0, 10° = volle Opazität (0.2)
- **Nacht-Overlay-Opazität:** gegenläufig. 10° = 0, 0° = volle Opazität (0.35)
- Formel: `t = clamp(altitude / 10, 0, 1)`. Schatten = `0.2 * t`, Nacht = `0.35 * (1 - t)`
- Das Nacht-Overlay deckt die **gesamte Weltkarte** ab (keine sichtbaren Kanten beim Pannen)
- Schatten-Layer liegt unterhalb der 3D-Gebäude (korrekte Z-Order via Mapbox `beforeId`)

### 9. Performance-Modell

- Gebäude- und POI-Abfragen laufen auf `map.idle` (nachdem alle Tiles geladen sind)
- Gebäudeabfrage mit 200px-Puffer über den Viewport hinaus (weiche Schattenkanten)
- Slider-Änderungen lösen `requestAnimationFrame`-entprellte Neuberechnung aus
- Schatten-Mathematik ist reine Arithmetik — keine externen Aufrufe, kein async
- Deduplizierung via Set (Gebäude aus überlappenden Tiles tauchen mehrfach auf)

---

## Integrationspfade

### Pfad A: Bestehenden Code mit dieser Logik ertüchtigen

Wenn du bereits eine Karte mit Gebäuden und ein Schattensystem hast, das Bugs aufweist, extrahiere die reinen Funktionen aus der Referenz:

1. `sunPos(date, utcHour, lat, lon)` — Sonnenpositionsrechner (UTC-Eingabe)
2. `shadowOff(height, sun, lat)` — Schatten-Offset in Grad (beide Komponenten negiert)
3. `hull(points)` — Monotone-Chain konvexe Hülle
4. `bldShadow(ring, height, sun, lat)` — komplettes Schattenpolygon für ein Gebäude
5. `pip(px, py, ring)` — Punkt-in-Polygon-Test

Diese haben null Abhängigkeiten. Sie arbeiten mit einfachen Koordinaten-Arrays `[lon, lat]`. Verdrahte sie mit deiner bestehenden Daten-Pipeline.

**Häufige Bugs in bestehenden Implementierungen:**
- Schatten-Offset nur halb negiert (dy negiert, dx nicht) — spiegelt die Ost-West-Richtung
- Schattenlänge nicht gedeckelt bei niedrigem Sonnenstand (erzeugt Infinity/NaN-Offsets)
- Cap zu hoch (z.B. `h * 15`) — erzeugt unrealistisch lange Schatten in der Dämmerung
- Fehlende Zeitgleichungs-Korrektur (Schatten bis zu 15 Minuten versetzt)
- Punkt-in-Polygon auf dem EIGENEN Gebäudeschatten markiert alles als beschattet
- Keine Deduplizierung von Gebäuden aus überlappenden Vector Tiles
- Konvexe-Hülle-Algorithmus der bei kollinearen Punkten versagt (Gift-Wrapping ist fragil; Monotone Chain verwenden)
- Abgehackte Schattenkanten am Viewport-Rand (fehlender Abfrage-Puffer)
- Abrupter Tag-Nacht-Wechsel statt fließendem Crossfade
- Zeitzonen ignoriert: gleiche Slider-Zeit für alle Längengrade (14:00 Berlin = 14:00 Tokyo)

### Pfad B: Auf Mapbox GL JS umsteigen

Wenn der aktuelle Kartenanbieter keine 3D-Gebäudedaten oder zuverlässige POI-Layer bietet, ist der Umstieg auf Mapbox empfohlen.

**Voraussetzungen:**
- Mapbox GL JS v3.x (CDN oder npm)
- Ein Mapbox Access Token (siehe Sicherheitsabschnitt unten)
- Ein Style mit Gebäudedaten (z.B. `light-v11`, `streets-v12`, `dark-v11`)

Die Referenzdatei kann nahezu direkt verwendet werden — einfach einen gültigen Token einsetzen.

---

## Sicherheitsanforderungen

### Umgang mit API-Tokens

**NIEMALS API-Tokens im Frontend-Quellcode hardcoden.**

Empfohlene Ansätze, in Präferenzreihenfolge:

1. **Umgebungsvariable zur Build-Zeit** — über Bundler injizieren (Vite, Webpack, esbuild). Der Token wird ins Build-Artefakt eingebaut, aber liegt nicht in der Versionskontrolle.
   ```js
   mapboxgl.accessToken = import.meta.env.VITE_MAPBOX_TOKEN;
   ```

2. **Serverseitiger Proxy** — das Frontend ruft einen eigenen Backend-Endpunkt auf, der Mapbox-Tile-Requests mit dem Token serverseitig weiterleitet. Der Token erreicht nie den Browser.

3. **Token-URL-Einschränkungen** — falls ein öffentlicher Token unvermeidbar ist (z.B. statische Seite), den Mapbox-Token im Dashboard mit URL-Restrictions konfigurieren, damit er nur von erlaubten Domains funktioniert.

4. **Eingabeaufforderung beim Laden** — nur für Entwicklung/Prototyping: den Nutzer bitten, seinen Token einzufügen.
   ```js
   mapboxgl.accessToken = localStorage.getItem('mapbox_token')
     || prompt('Mapbox Access Token eingeben:');
   if (mapboxgl.accessToken) localStorage.setItem('mapbox_token', mapboxgl.accessToken);
   ```

Die Referenzdatei verwendet Option 4 (localStorage + Prompt). Für Produktion Option 1 oder 2 verwenden.

### Content Security Policy

Bei Deployment hinter einer CSP erlauben:
- `https://api.mapbox.com` (Tiles, Styles, Glyphen, Sprites)
- `https://events.mapbox.com` (Telemetrie, kann blockiert werden)
- `blob:` (für Web Workers)

---

## Code-Qualitäts-Checkliste

Bei Integration oder Neuentwicklung sicherstellen:

- [ ] Sonnenberechnung verwendet Zeitgleichungs-Korrektur
- [ ] Sonnenberechnung nimmt UTC als Eingabe, Solarzeit direkt aus `utcHour + lon / 15`
- [ ] Schatten-Offset negiert BEIDE Komponenten (dx UND dy)
- [ ] Schattenlänge ist gedeckelt bei `Höhe * 4` (nicht höher)
- [ ] Punkt-in-Schatten-Test schließt den Grundriss des Quellgebäudes aus
- [ ] Gebäude werden nach Tile-Abfrage dedupliziert
- [ ] Gebäudeabfrage mit Viewport-Puffer (z.B. 200px) für weiche Kanten
- [ ] Neuberechnung ist entprellt (nicht bei jedem Frame/Pixel des Schwenkens)
- [ ] Tag-Nacht-Crossfade implementiert (kein abrupter Wechsel)
- [ ] Nachts alle Restaurants als `shadowed: true` markiert
- [ ] Nacht-Overlay deckt gesamte Weltkarte ab (keine Kanten beim Pannen)
- [ ] Schatten-Layer unterhalb der 3D-Gebäude (korrekter `beforeId`)
- [ ] Slider verschiebt sich automatisch beim Zeitzonen-Wechsel
- [ ] UTC-Konvertierung korrekt: `utcHour = (localHour - round(lon/15) + 24) % 24`
- [ ] API-Tokens sind nicht in die Versionskontrolle eingecheckt
- [ ] Funktioniert an jeder Kartenposition wo Mapbox 3D-Gebäudedaten hat (Zoom 14+)

---

## Funktionsreferenz

| Funktion | Eingabe | Ausgabe | Zweck |
|----------|---------|---------|-------|
| `sunPos` | Date, UTC-Stunde, lat, lon | `{alt, az, up}` | Sonnenposition aus UTC |
| `shadowOff` | Höhe, sun, lat | `[dLon, dLat]` | Schatten-Offset in Grad (beide negiert) |
| `hull` | `[[x,y], ...]` | `[[x,y], ...]` | Konvexe Hülle (Monotone Chain) |
| `bldShadow` | ring, Höhe, sun, lat | geschlossener Ring | Schattenpolygon für ein Gebäude |
| `pip` | px, py, ring | boolean | Punkt-in-Polygon (Ray Casting) |
