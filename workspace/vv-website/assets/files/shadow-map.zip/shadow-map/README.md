# Shadow Map

Rendert Gebäudeschatten in Echtzeit auf einer interaktiven Karte — abhängig von Uhrzeit, Datum und Standort. Restaurants werden als grüne Punkte dargestellt: hellgrün in der Sonne, dunkelgrün im Schatten.

---

## Dateien

| Datei | Zweck |
|-------|-------|
| `shadow-map.html` | Funktionierende Referenzimplementierung (braucht einen Mapbox-Token) |
| `shadow-map.llm.md` | Anweisungen für KI-Coding-Assistenten (Claude Code, Cursor, etc.) |

---

## Loslegen

### 1. Mapbox-Token besorgen

1. Kostenloses Konto anlegen unter [mapbox.com](https://account.mapbox.com/auth/signup/)
2. Den **Default public token** aus dem Dashboard kopieren

### 2. Token einsetzen

`shadow-map.html` öffnen und den geschwärzten Token in dieser Zeile:

```js
mapboxgl.accessToken = "pk.eyJ1Ijoid**************";
```

durch deinen eigenen ersetzen:

```js
mapboxgl.accessToken = "pk.eyJ1Ijoi...dein-token-hier...";
```

### 3. Im Browser öffnen

Doppelklick auf `shadow-map.html` oder lokal servieren. Kein Build-Schritt, keine Abhängigkeiten.

---

## Bedienung

- **Zeit-Slider** — Uhrzeit einstellen (15-Minuten-Schritte)
- **Datumsfeld** — beliebiges Datum wählen
- **Navigieren** — zu jeder Stadt schwenken/zoomen, Schatten berechnen sich automatisch neu
- **Punkt anklicken** — zeigt Restaurantname und Sonnen-/Schattenstatus
- **Standort-Button** (oben rechts) — springt zur aktuellen Position

Schatten erscheinen ab Zoomstufe 14+, wo Mapbox 3D-Gebäudedaten hat.

---

## Mit der KI-Anweisung arbeiten

Die Datei `shadow-map.llm.md` ist für KI-Coding-Assistenten geschrieben. So verwendest du sie:

1. Dein Projekt in Claude Code (oder ähnlich) öffnen
2. Den Assistenten auf beide Dateien verweisen:
   ```
   Lies map/shadow-map.html und map/shadow-map.llm.md,
   dann integriere die Schatten-Logik in mein Projekt.
   ```
3. Der Assistent wird entweder deinen vorhandenen Code anpassen oder empfehlen, auf den Mapbox-Ansatz umzusteigen — je nachdem was du bereits hast

Die `.llm.md` dokumentiert jede Funktion, bekannte Stolperfallen und Sicherheits-Best-Practices, damit der Assistent fundierte Entscheidungen treffen kann.

---

## Sicherheitshinweis

Den Mapbox-Token niemals in ein öffentliches Repository committen. Für Produktiveinsatz siehe die Token-Optionen in `shadow-map.llm.md`.
